﻿
namespace NMEA
{
    public sealed class NMEAStandartSentese : NMEASentense
    {
        public TalkerIdentifiers TalkerID { get; set; }
        public SentenseIdentifiers SentenseID { get; set; }        
    }
}
