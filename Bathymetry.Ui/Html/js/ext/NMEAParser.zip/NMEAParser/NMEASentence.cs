﻿
namespace NMEA
{
    public abstract class NMEASentence
    {
        public object[] parameters;
    }
}
