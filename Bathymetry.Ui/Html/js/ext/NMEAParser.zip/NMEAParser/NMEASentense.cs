﻿
namespace NMEA
{
    public abstract class NMEASentense
    {
        public object[] parameters;
    }
}
